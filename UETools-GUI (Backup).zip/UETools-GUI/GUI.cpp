#include "GUI.h"






void GUI::Create(const HMODULE& applicationModule)
{
	DirectWindow::SetApplicationModule(applicationModule);
	SetUserInterfaceThread(CreateThread(0, 0, (LPTHREAD_START_ROUTINE)DirectWindow::Construct, 0, 0, 0));
}




void GUI::Draw()
{
	if (GetIsActive())
	{
		ImGui::ShowDemoWindow();
		if (ImGui::BeginMainMenuBar())
		{
			static float a = 1.0f;
			if (ImGui::BeginMenu("General"))
			{
				ImGui::SliderFloat("Time Scale", &a, 0.001f, 3.0f);
				ImGui::EndMenu();
			}
			if (ImGui::BeginMenu("Edit"))
			{
				if (ImGui::MenuItem("Undo", "CTRL+Z")) {}
				if (ImGui::MenuItem("Redo", "CTRL+Y", false, false)) {} // Disabled item
				ImGui::Separator();
				if (ImGui::MenuItem("Cut", "CTRL+X")) {}
				if (ImGui::MenuItem("Copy", "CTRL+C")) {}
				if (ImGui::MenuItem("Paste", "CTRL+V")) {}
				ImGui::EndMenu();
			}
			ImGui::EndMainMenuBar();
		}
		//ImGui::SetNextWindowSize(GetWindowSize(), ImGuiCond_Once);
		//ImGui::SetNextWindowBgAlpha(1.0f);
		//ImGui::Begin(windowTitle, &isActive, WindowFlags);
		//{
		//	if (ImGui::BeginTabBar("MainTabs")) 
		//	{
		//		if (ImGui::BeginTabItem("General")) {
		//			if (ImGui::Button("Size"))
		//			{
		//				SetWindowSize({ 500, 500 });
		//				Beep(300, 100);
		//			}
		//
		//			ImGui::SameLine();
		//
		//			if (ImGui::Button("Title"))
		//			{
		//				SetWindowTitle("Fuck YEAH");
		//				Beep(300, 100);
		//			}
		//
		//			ImGui::EndTabItem();
		//		}
		//
		//		if (ImGui::BeginTabItem("Advanced")) {
		//			if (ImGui::Button("Run"))
		//				Beep(100, 100);
		//
		//			ImGui::SameLine();
		//
		//			if (ImGui::Button("Stop"))
		//				Beep(300, 100);
		//
		//			ImGui::EndTabItem();
		//		}
		//
		//		ImGui::EndTabBar();
		//	}
		//
		//	
		//	ImGui::Text("Create your own menu.");
		//	ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
		//}
		//ImGui::End();
	}

	if (GetAsyncKeyState(VK_INSERT) & 1)
		ToggleIsActive();
}




void GUI::Invalidate()
{
	if (GetUserInterfaceThread())
		TerminateThread(GetUserInterfaceThread(), 0);
}
