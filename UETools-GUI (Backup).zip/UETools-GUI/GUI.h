#pragma once
#include "DirectWindow.h"

#include "imgui.h"
#include <Windows.h>


class GUI
{
private:
	static inline HANDLE userInterfaceThread = nullptr;
public:
	static HANDLE GetUserInterfaceThread()
	{
		return userInterfaceThread;
	}
	static void SetUserInterfaceThread(const HANDLE& newUserInterfaceThread)
	{
		userInterfaceThread = newUserInterfaceThread;
	}




private:
	static inline bool isActive = true;
public:
	static bool GetIsActive()
	{
		return isActive;
	}
	static void SetIsActive(const bool& newIsActive)
	{
		isActive = newIsActive;
	}
	static void ToggleIsActive()
	{
		isActive = !isActive;
	}




private:
	static inline ImGuiWindowFlags windowFlags = 0;
public:
	static ImGuiWindowFlags GetWindowFlags()
	{
		return windowFlags;
	}
	static void SetWindowFlags(const ImGuiWindowFlags& newWindowFlags)
	{
		windowFlags = newWindowFlags;
	}




private:
	static inline LPCSTR windowTitle = "ImGui Window";
public:
	static LPCSTR GetWindowTitle()
	{
		return windowTitle;
	}
	static void SetWindowTitle(const LPCSTR& newWindowTitle)
	{
		windowTitle = newWindowTitle;
	}




private:
	static inline ImVec2 windowSize = { 640, 480 };
public:
	static ImVec2 GetWindowSize()
	{
		return windowSize;
	}
	static void SetWindowSize(const ImVec2& newWindowSize)
	{
		windowSize = newWindowSize;
	}




public:
	static void Create(const HMODULE& applicationModule);
	static void Draw();
	static void Invalidate();
};

